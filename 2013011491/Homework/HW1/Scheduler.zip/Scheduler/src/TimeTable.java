

public class TimeTable {
	private String day;
	Course[] times = new Course[10];
	
	public TimeTable() {
		day = null;
		for(int i=0; i<10; i++) {
			times[i] = new Course();
		}
		
	}
	public String getDay() {
		return day;
	}
	public void setDay(String day) {
		this.day=day;
	}
	public int setTimes(int index, Course a) {
		if(times[index].getName()==null) {
			times[index]=a;
			return 1;
		}
		else if(times[index].equals(a)) return 0;
		else return -1;
	}
	public Course getTimes(int index) {
		return times[index];
	}
	public Course[] getAllTimes() {
		return times;
	}
	public boolean isEmptyTime(int index) {
		return times[index].getName()==null;
	}
}
