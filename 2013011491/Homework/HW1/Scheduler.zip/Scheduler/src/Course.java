

public class Course {
	private String name;
	private String instructor;
	private String room;

	public Course(){
		name=null;
		instructor=null;
		room=null;
	}
	
	public Course(String name){
		this.name=name;
		instructor=null;
		room=null;
	}
	public Course(String name, String instructor){
		this.name=name;
		this.instructor=instructor;
		room=null;
	}
	public Course(String name, String instructor, String room){
		this.name=name;
		this.instructor=instructor;
		this.room=room;
	}

	public String getName(){
		return name;
	}
	public void setName(String name){
		this.name=name;
	}
	public String getInstructor(){
		return instructor;
	}
	public void setInstructor(String instructor){
		this.instructor=instructor;
	}
	public String getRoom(){
		return room;
	}
	public void setRoom(String room){
		this.room=room;
	}
	public boolean equals(Course a){
		if(name==a.name&&instructor==a.instructor&&room==a.room) return true;
		else return false;
	}
	public String toString() {
		return "["+name+"]"+"(["+instructor+")] - #["+room+"]";
	}
	
	public static boolean isDuplicatedCourse(Course a, Course b) {
			return !a.equals(b);
	}
}

