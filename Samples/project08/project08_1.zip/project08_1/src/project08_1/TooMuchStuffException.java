package project08_1;

public class TooMuchStuffException extends Exception {

	private int inputNumber;
	
	public TooMuchStuffException(/* your code */) {
		/* your code */
	}
	
	public TooMuchStuffException() {
		/* your code */
	}
	
	public TooMuchStuffException(/* your code */) {
		/* your code */
	}
	
	public int getNumber() {
		/* your code */
	}
}
