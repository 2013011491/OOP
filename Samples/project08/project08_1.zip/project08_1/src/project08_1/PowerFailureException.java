package project08_1;

public class PowerFailureException extends Exception {

	public PowerFailureException() {
		/* your code */
	}
	
	public PowerFailureException(/* your code */) {
		/* your code */
	}

}
