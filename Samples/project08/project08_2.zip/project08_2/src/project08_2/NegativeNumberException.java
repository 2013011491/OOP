package project08_2;

public class NegativeNumberException extends Exception{
	
	public NegativeNumberException() {
		/* your code */
	}
	
	public NegativeNumberException(/* your code */) {
		/* your code */
	}	
}
