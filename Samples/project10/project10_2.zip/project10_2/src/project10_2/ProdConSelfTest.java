package project10_2;

public class ProdConSelfTest {
	
	private Buffer buffer;
	private Producer producer;
	private Consumer consumer;
	
	public ProdConSelfTest() {
		/* your code */
	}
	
	private class Producer extends Thread{
		private final Buffer buffer;
		
		/* your code */
	}
	
	private class Consumer extends Thread{
		private final Buffer buffer;
		
		/* your code */
	}
	
	public void startThread() {
		/* your code */
	}
}
