package project10_2;

public class ProducerConsumer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ProdConSelfTest a = new ProdConSelfTest();
		a.startThread();
	}

}
