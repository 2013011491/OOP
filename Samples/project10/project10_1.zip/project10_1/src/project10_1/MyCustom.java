package project10_1;

import java.util.Arrays;

public class MyCustom {
	private Integer move_type = 0;
	private Boolean isAttack = false;
	
	public void move(String key) {
		/* your code */
	}
	public void attack(String key) {
		/* your code */
	}
	public void sortItem(Item[] itemList) {
		/* your code */
	}
	public Integer getMoveType() {
		/* your code */
	}
	public Boolean getIsAttack() {
		/* your code */
	}
}