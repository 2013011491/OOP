package project06_1;

public class Employee {
	String name;
	int employeeNum;
	String department;
	
	public Employee(String name, int employeeNum) {
		/* your code */
	}
	
	public String getDepartment() { /* your code */ }
	public void setDepartment(String dept) { /* your code */ }
	
	public boolean equals(Employee compare) {
		/* your code */
	}
	
	public String toString() { /* your code */ }
}
