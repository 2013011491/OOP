package project06_1;

public class Manager extends Employee {
	int officeNum;
	String team;
	
	public Manager(String name, int employeeNum, int officeNum, String team) {
		/* your code */
	}
	
	public boolean equals(Manager compare) {
		/* your code */
	}
	
	public String toString() {
		/* your code */ 
	}
}