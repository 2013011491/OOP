package project06_1;

public class Engineer extends Employee {
	String workZone;
	String project;
	
	public Engineer(String name, int employeeNum, String workZone, String project) {
		/* your code */
	}
	
	public boolean equals(Engineer compare) {
		/* your code */			
	}
	
	public String toString() {
		/* your code */
	}
}