package project05_2;

import java.util.Scanner;

public class EnumValuesDemo {

	/* your code */
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/* your code */
		
	}
}
