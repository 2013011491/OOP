package project04_2;

public class Cities {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		City city1 = new City("Seoul");
		City city2 = new City("Paris", 133, 251);
		City city3 = new City("Paris", 133, 251);
		City city4 = new City("Raccon City", 30, 250);
		City city5 = new City("Mega City", 310, 170);

		System.out.println("Seoul Information: " + /*your code*/);
		System.out.println("Mega City Information: "+ /*your code*/);
		System.out.println();
		
		System.out.println("Paris-Paris: " + /*your code*/);
		System.out.println("Seoul-Paris: " + /*your code*/);
		System.out.println();
		
		System.out.println("Seoul-Pris: " + /*your code*/);
		System.out.println("Seoul-Racoon City: " + /*your code*/);
		System.out.println("Paris-Mega City: " + /*your code*/);
		
	}

}
