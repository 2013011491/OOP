package project04_2;

public class City {
	
	private String name;
	private double lat;
	private double lon;
	
	public City() {}
	
	public City(/*your code*/) {
		/*your code*/
	}
	
	public City(/*your code*/) {
		/*your code*/
	}
	
	public boolean equals(/*your code*/) {
		/*your code*/
	}
	
	public String toString() {
		/*your code*/
	}
	
	public static double cityDistance(/*your code*/) {
		/*your code*/
	}
}
