package project04_1;

public class MathEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a = 60984;
		int b = 808;
		
		double x = 2.0;
		double y = 3.0;
		
		System.out.println("Maximum: " + /* your code */);
		System.out.println("Mininum: " + /* your code */);
		System.out.println("x^y: " + /* your code */);
		System.out.println("y^x: " + /* your code */);
	}

}
