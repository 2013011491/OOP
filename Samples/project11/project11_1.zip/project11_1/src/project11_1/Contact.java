package project11_1;

public class Contact /* your code */{
	private String name;
	private String telNum;
	private String email;
	
	public Contact(String name, String telNum, String email) {
		/* your code */
	}
	
	public Contact(String name) {
		/* your code */
	}
	
	public String getTelNum() {	/* your code */ }
	public void setTelNum(String telNum) { /* your code */ }
	public String getEmail() { /* your code */ }
	public void setEmail(String email) { /* your code */ }
	public String getName() { /* your code */ }
	
	public String toString() {
		return "Name: " + name + "\ttelNum: " + telNum + "\temail: " + email + "\n";
	}
	
	public boolean equals(Object obj) {
		/* your code */
	}
	
	public int compareTo(Object obj) {
		if(obj==null) throw new NullPointerException("Object is null");
		else if(this.getClass()!=obj.getClass()) throw new ClassCastException("Object not of the same type");
		else {
			Contact otherManager = (Contact) obj;
			int compare = this.getName().compareTo(otherManager.getName());
			return compare;
		}
	}
}
