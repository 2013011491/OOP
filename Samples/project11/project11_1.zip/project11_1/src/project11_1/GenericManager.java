package project11_1;

import java.util.ArrayList;
import java.util.Collections;

public class GenericManager /* your code */{
	private ArrayList<T> cList;

	public GenericManager() {
		/* your code */
	}
	
	public void add(T a) {
		/* your code */
	}
	
	public void sort() {
		Collections.sort(cList);
	}
	
	public String find(T a) {
		/* your code */
	}
	
	public String toString() {
		/* your code */
	}
}
