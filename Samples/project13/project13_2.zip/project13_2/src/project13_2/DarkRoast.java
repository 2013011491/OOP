package project13_2;

public class DarkRoast extends Beverage {
	
	public DarkRoast() {
		description = "Dark roast";
	}
	
	public double cost() { return .99; }

}
