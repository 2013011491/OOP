package project13_2;

public class Cinnamon /* your code */{
	/* your code */
}
