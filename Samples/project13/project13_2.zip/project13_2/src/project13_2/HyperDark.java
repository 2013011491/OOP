package project13_2;

public class HyperDark /* your code */ {
	/* your code */
}
