package project13_1;

public interface Observer {
	public abstract void update(NumberGenerator generator);
}
