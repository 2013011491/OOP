package project03_4;

public class Employee {

	/* Write the code */
	
	public Employee() {}
	
	public Employee(/* Write the code */) {
		/* Write the code */
	}
	
	public Employee(/* Write the code */) {
		/* Write the code */
	}
	
	public Employee(/* Write the code */) {
		/* Write the code */
	}
	
	public void setSalary(/* Write the code */) {
		/* Write the code */
	}
	
	public void outInfo() {
		/* Write the code */
	}
	
	public String vacation(/* Write the code */) {
		/* Write the code */
	}
}
