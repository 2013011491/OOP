package project03_3;

public class DateFirstTry {
	
	/*Write the Code*/
	
	public void makeItNewYears() {
		/*Write the Code*/
	}
	
	public String yellIfNewYear() {
		/*Write the Code*/
	}
}
